const state = {
  recording: false,
  paused: false,
  sessionId: null,
  startedAt: null,
  pausedAt: null,
  pausedTotalMs: 0,
  events: [],
  chapters: [],
  stateVersion: 0
};

async function setRecordingIndicator(active, paused = false) {
  try {
    if (!active) {
      // Inactive = no badge at all.
      await chrome.action.setBadgeText({ text: "" });
      return;
    }

    await chrome.action.setBadgeText({ text: "●" });
    await chrome.action.setBadgeBackgroundColor({
      color: paused ? "#ffc857" : "#e5484d"
    });
    await chrome.action.setBadgeTextColor({ color: "#ffffff" });
  } catch (error) {
    console.warn("KTVis.IT recording indicator update failed:", error);
  }
}

async function ensureOffscreen() {
  const url = chrome.runtime.getURL("src/offscreen.html");
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [url]
  });

  if (!contexts.length) {
    await chrome.offscreen.createDocument({
      url: "src/offscreen.html",
      reasons: ["DISPLAY_MEDIA"],
      justification: "Record a user-approved screen, window, or Chrome tab for a knowledge-transfer session."
    });
  }
}

async function sendOffscreen(message) {
  await ensureOffscreen();
  return chrome.runtime.sendMessage(message);
}

async function sendOffscreenControl(message, timeoutMs = 3000) {
  await ensureOffscreen();

  const timeout = new Promise(resolve => {
    setTimeout(() => {
      resolve({
        ok: false,
        error: `Offscreen capture control did not respond within ${timeoutMs} ms.`
      });
    }, timeoutMs);
  });

  return Promise.race([
    chrome.runtime.sendMessage(message),
    timeout
  ]);
}

function elapsedMs() {
  if (!state.startedAt) return 0;
  const now = state.pausedAt || Date.now();
  return Math.max(0, now - state.startedAt - state.pausedTotalMs);
}

function broadcast(message) {
  chrome.tabs.query({}).then(tabs => {
    for (const tab of tabs) {
      if (tab.id) chrome.tabs.sendMessage(tab.id, message).catch(() => {});
    }
  });
}

function addEvent(event) {
  if (!state.recording || state.paused) return;

  state.events.push({
    ...event,
    recordedAt: Date.now(),
    relativeMs: elapsedMs()
  });
}

async function persistSession(session) {
  const data = await chrome.storage.local.get({ sessions: [] });
  const sessions = Array.isArray(data.sessions) ? data.sessions : [];
  sessions.unshift(session);
  await chrome.storage.local.set({ sessions: sessions.slice(0, 20) });
}

async function stopRecording() {
  if (!state.recording) return { ok: false, error: "No active recording." };

  // If paused, close the pause interval before finalizing.
  if (state.paused && state.pausedAt) {
    state.pausedTotalMs += Date.now() - state.pausedAt;
  }

  state.recording = false;
  state.paused = false;
  state.pausedAt = null;

  let videoResult;
  try {
    videoResult = await sendOffscreen({ type: "STOP_CAPTURE" });
  } catch (error) {
    videoResult = { ok: false, error: error.message };
  }

  const endedAt = Date.now();
  const durationMs = elapsedMs();

  await setRecordingIndicator(false);

  const session = {
    id: state.sessionId,
    title: "KT Session",
    description: "",
    createdAt: state.startedAt,
    endedAt,
    durationMs,
    eventCount: state.events.length,
    events: state.events,
    chapters: state.chapters,
    video: videoResult?.video || null,
    videoError: videoResult?.ok ? null : (videoResult?.error || null)
  };

  await persistSession(session);
  state.stateVersion += 1;
  broadcast({
    type: "RECORDING_STATE",
    recording: false,
    paused: false,
    elapsedMs: 0,
    stateVersion: state.stateVersion
  });

  state.sessionId = null;
  state.startedAt = null;
  state.pausedAt = null;
  state.pausedTotalMs = 0;
  state.events = [];
  state.chapters = [];

  return { ok: true, session };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "START_RECORDING") {
    (async () => {
      if (state.recording) {
        sendResponse({ ok: false, error: "A recording is already active." });
        return;
      }

      state.recording = true;
      state.paused = false;
      state.sessionId = crypto.randomUUID();
      state.startedAt = Date.now();
      state.pausedAt = null;
      state.pausedTotalMs = 0;
      state.events = [];
      state.chapters = [];
      state.stateVersion += 1;

      try {
        const result = await sendOffscreen({
          type: "START_DISPLAY_CAPTURE",
          sessionId: state.sessionId
        });

        if (!result?.ok) {
          state.recording = false;
          await setRecordingIndicator(false);
          sendResponse({ ok: false, error: result?.error || "Unable to start display capture." });
          return;
        }

        await setRecordingIndicator(true);
        broadcast({
          type: "RECORDING_STATE",
          recording: true,
          paused: false,
          elapsedMs: elapsedMs(),
          stateVersion: state.stateVersion
        });
        sendResponse({
          ok: true,
          sessionId: state.sessionId,
          startedAt: state.startedAt
        });
      } catch (error) {
        state.recording = false;
        await setRecordingIndicator(false);
        sendResponse({
          ok: false,
          error: `${error.name || "CaptureError"}: ${error.message || "Unable to start recording."}`
        });
      }
    })();
    return true;
  }

  if (message?.type === "PAUSE_RECORDING") {
    (async () => {
      if (!state.recording || state.paused) {
        sendResponse({ ok: false, error: "Recording is not currently running." });
        return;
      }

      try {
        const result = await sendOffscreenControl({ type: "PAUSE_CAPTURE" });
        if (!result?.ok || result.state !== "paused") {
          sendResponse({
            ok: false,
            error: result?.error || `Recorder did not enter paused state (current: ${result?.state || "unknown"}).`
          });
          return;
        }

        state.paused = true;
        state.pausedAt = Date.now();
        state.stateVersion += 1;

        await setRecordingIndicator(true, true);

        const elapsed = elapsedMs();
        broadcast({
          type: "RECORDING_STATE",
          recording: true,
          paused: true,
          elapsedMs: elapsed,
          stateVersion: state.stateVersion
        });

        sendResponse({
          ok: true,
          recording: true,
          paused: true,
          elapsedMs: elapsed,
          stateVersion: state.stateVersion
        });
      } catch (error) {
        sendResponse({ ok: false, error: error.message || "Unable to pause recording." });
      }
    })();
    return true;
  }

  if (message?.type === "RESUME_RECORDING") {
    (async () => {
      if (!state.recording || !state.paused) {
        sendResponse({ ok: false, error: "Recording is not currently paused." });
        return;
      }

      try {
        const result = await sendOffscreenControl({ type: "RESUME_CAPTURE" });
        if (!result?.ok || result.state !== "recording") {
          sendResponse({
            ok: false,
            error: result?.error || `Recorder did not enter recording state (current: ${result?.state || "unknown"}).`
          });
          return;
        }

        const now = Date.now();
        if (state.pausedAt) {
          state.pausedTotalMs += now - state.pausedAt;
        }
        state.pausedAt = null;
        state.paused = false;
        state.stateVersion += 1;

        await setRecordingIndicator(true);

        const elapsed = elapsedMs();
        broadcast({
          type: "RECORDING_STATE",
          recording: true,
          paused: false,
          elapsedMs: elapsed,
          stateVersion: state.stateVersion
        });

        sendResponse({
          ok: true,
          recording: true,
          paused: false,
          elapsedMs: elapsed,
          stateVersion: state.stateVersion
        });
      } catch (error) {
        sendResponse({ ok: false, error: error.message || "Unable to resume recording." });
      }
    })();
    return true;
  }

  if (message?.type === "ADD_CHAPTER") {
    if (!state.recording || state.paused) {
      sendResponse({ ok: false, error: "Resume recording before adding a chapter." });
      return true;
    }

    const name = String(message.name || "").trim();
    if (!name) {
      sendResponse({ ok: false, error: "Chapter name is required." });
      return true;
    }

    const chapter = {
      id: crypto.randomUUID(),
      title: name.slice(0, 120),
      timestampMs: elapsedMs()
    };

    state.chapters.push(chapter);
    sendResponse({ ok: true, chapter });
    return true;
  }

  if (message?.type === "STOP_RECORDING") {
    stopRecording().then(sendResponse);
    return true;
  }

  if (message?.type === "GET_STATUS") {
    sendResponse({
      ok: true,
      recording: state.recording,
      paused: state.paused,
      sessionId: state.sessionId,
      startedAt: state.startedAt,
      elapsedMs: elapsedMs(),
      eventCount: state.events.length,
      chapters: state.chapters,
      stateVersion: state.stateVersion
    });
    return true;
  }

  if (message?.type === "EVENT") {
    if (!state.recording || state.paused) {
      sendResponse({ ok: false, ignored: true });
      return true;
    }

    addEvent({
      ...message.event,
      tabId: sender.tab?.id ?? null,
      windowId: sender.tab?.windowId ?? null
    });

    sendResponse({ ok: true, eventCount: state.events.length });
    return true;
  }

  if (message?.type === "GET_SESSIONS") {
    chrome.storage.local.get({ sessions: [] }).then(data => {
      sendResponse({ ok: true, sessions: data.sessions || [] });
    });
    return true;
  }

  if (message?.type === "DOWNLOAD_VIDEO") {
    (async () => {
      try {
        const id = await chrome.downloads.download({
          url: message.dataUrl,
          filename: message.filename || `KTVis.IT-KT-${Date.now()}.webm`,
          saveAs: true,
          conflictAction: "uniquify"
        });
        sendResponse({ ok: true, downloadId: id });
      } catch (error) {
        sendResponse({ ok: false, error: error.message });
      }
    })();
    return true;
  }
});
