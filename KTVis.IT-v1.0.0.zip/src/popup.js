let timerHandle = null;
let statusSyncHandle = null;
let recordingStartedAt = null;
let paused = false;
let displayElapsedMs = 0;
let displaySyncedAt = 0;
let stateVersion = -1;
let latestSession = null;

const $ = id => document.getElementById(id);

function show(id) {
  // Only the three current popup sections are user-facing.
  ["idle", "recording", "complete"].forEach(view => {
    const element = $(view);
    if (element) {
      element.classList.toggle("hidden", view !== id);
    }
  });
}

function formatDuration(ms) {
  const seconds = Math.max(0, Math.floor(ms / 1000));
  return `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
}

function elapsed() {
  if (!recordingStartedAt) return 0;
  return Math.max(0, displayElapsedMs);
}

async function syncAuthoritativeStatus() {
  const status = await chrome.runtime.sendMessage({ type: "GET_STATUS" }).catch(() => null);
  if (!status?.ok || !status.recording) return;

  if (typeof status.stateVersion === "number" && status.stateVersion < stateVersion) {
    return;
  }

  if (typeof status.stateVersion === "number") stateVersion = status.stateVersion;
  paused = Boolean(status.paused);

  if (typeof status.elapsedMs === "number" && Number.isFinite(status.elapsedMs)) {
    displayElapsedMs = Math.max(0, status.elapsedMs);
  }

  const timer = $("timer");
  if (timer) timer.textContent = formatDuration(elapsed());
}

function startTimer() {
  clearInterval(timerHandle);
  clearInterval(statusSyncHandle);

  timerHandle = setInterval(() => {
    const timer = $("timer");
    if (timer) timer.textContent = formatDuration(elapsed());
  }, 100);

  statusSyncHandle = setInterval(() => {
    syncAuthoritativeStatus().catch(() => {});
  }, 500);

  syncAuthoritativeStatus().catch(() => {});
}

function stopTimer() {
  clearInterval(timerHandle);
  clearInterval(statusSyncHandle);
  timerHandle = null;
  statusSyncHandle = null;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function formatBytes(bytes) {
  if (!bytes) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  const i = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  return `${(bytes / Math.pow(1024, i)).toFixed(i ? 1 : 0)} ${units[i]}`;
}

function detailFor(event) {
  return event.element?.text || event.element?.label || event.selectedText || event.value || event.url || "";
}

function renderChapters(session) {
  const list = $("chapterList");
  list.innerHTML = "";

  for (const chapter of session?.chapters || []) {
    const row = document.createElement("div");
    row.className = "chapter-item";
    row.innerHTML = `
      <span class="chapter-time">${formatDuration(chapter.timestampMs)}</span>
      <span class="chapter-title">${escapeHtml(chapter.title)}</span>
    `;
    row.addEventListener("click", () => {
      $("preview").currentTime = Math.max(0, chapter.timestampMs / 1000);
      $("preview").play().catch(() => {});
    });
    list.appendChild(row);
  }

  if (!session?.chapters?.length) {
    list.innerHTML = `<p>No chapters were added. You can add them in the next recording.</p>`;
  }
}


$("start").addEventListener("click", async () => {
  const response = await chrome.runtime.sendMessage({ type: "START_RECORDING" });

  if (!response?.ok) {
    alert(response?.error || "Unable to start recording.");
    return;
  }

  recordingStartedAt = response.startedAt;
  paused = false;
  displayElapsedMs = 0;
  stateVersion = -1;
  const dot = $("dot");
  if (dot) {
    dot.classList.add("active");
    dot.classList.remove("paused");
  }
  show("recording");
  startTimer();
});

$("stop").addEventListener("click", async () => {
  $("stop").disabled = true;
  $("stop").textContent = "Creating video…";

  const response = await chrome.runtime.sendMessage({ type: "STOP_RECORDING" });

  $("stop").disabled = false;
  $("stop").textContent = "■ Stop & Create KT Video";

  if (!response?.ok) {
    alert(response?.error || "Unable to stop recording.");
    return;
  }

  latestSession = response.session;
  stopTimer();
  const dot = $("dot");
  if (dot) {
    dot.classList.remove("active");
    dot.classList.remove("paused");
  }

  $("summary").textContent =
    `${formatDuration(latestSession.durationMs)} · ${latestSession.eventCount} browser actions · ${latestSession.chapters?.length || 0} chapters · ${latestSession.video ? formatBytes(latestSession.video.sizeBytes) : "video unavailable"}`;

  $("title").value = latestSession.title || "KT Session";
  $("description").value = latestSession.description || "";

  if (latestSession.video?.dataUrl) {
    $("preview").src = latestSession.video.dataUrl;
  } else {
    $("preview").removeAttribute("src");
  }

  renderChapters(latestSession);
  show("complete");
});

$("download").addEventListener("click", async () => {
  if (!latestSession?.video?.dataUrl) return;

  const safeTitle = ($("title").value || "KT-Session")
    .replace(/[^\w\- ]+/g, "")
    .trim()
    .replace(/\s+/g, "-");

  const response = await chrome.runtime.sendMessage({
    type: "DOWNLOAD_VIDEO",
    dataUrl: latestSession.video.dataUrl,
    filename: `KTVisIT-${safeTitle || "KT-Session"}-${new Date(latestSession.createdAt).toISOString().slice(0, 10)}.webm`
  });

  if (!response?.ok) alert(response?.error || "Download failed.");
});



$("new").addEventListener("click", () => {
  latestSession = null;
  $("preview").removeAttribute("src");
  show("idle");
});

chrome.runtime.onMessage.addListener(message => {
  if (message?.type !== "RECORDING_STATE") return;

  const dot = $("dot");

  if (!message.recording) {
    stopTimer();
    if (dot) dot.classList.remove("active");

    // If the popup is open when Stop is clicked from the floating controls,
    // immediately return it to the idle screen.
    if (!$("complete") || $("complete").classList.contains("hidden")) {
      show("idle");
    }
    return;
  }

  const incomingVersion =
    typeof message.stateVersion === "number" ? message.stateVersion : null;

  if (incomingVersion !== null && incomingVersion < stateVersion) return;
  if (incomingVersion !== null) stateVersion = incomingVersion;

  paused = Boolean(message.paused);

  if (typeof message.elapsedMs === "number" && Number.isFinite(message.elapsedMs)) {
    displayElapsedMs = Math.max(0, message.elapsedMs);
  }

  if (dot) {
    dot.classList.add("active");
    dot.classList.toggle("paused", paused);
  }

  // The popup can remain open while Pause/Resume is performed from the
  // floating controls. Keep the popup's visible state synchronized with
  // the same authoritative RECORDING_STATE broadcast.
  show("recording");
  const timer = $("timer");
  if (timer) timer.textContent = formatDuration(displayElapsedMs);
  startTimer();
});

(async () => {
  const status = await chrome.runtime.sendMessage({ type: "GET_STATUS" });

  if (status?.recording) {
    recordingStartedAt = Date.now() - Number(status.elapsedMs || 0);
    paused = Boolean(status.paused);
    displayElapsedMs = Math.max(0, Number(status.elapsedMs || 0));
    stateVersion = Number.isFinite(status.stateVersion) ? status.stateVersion : -1;
    const dot = $("dot");
    if (dot) {
      dot.classList.add("active");
      dot.classList.toggle("paused", paused);
    }
    show("recording");
    startTimer();
    return;
  }

  // If the recording was stopped from the floating overlay while the
  // popup was closed, show the newly persisted session when the popup
  // is opened again.
  const sessionsResponse = await chrome.runtime.sendMessage({ type: "GET_SESSIONS" });
  const newest = sessionsResponse?.sessions?.[0];

  if (newest?.video?.dataUrl) {
    latestSession = newest;
    $("summary").textContent =
      `${formatDuration(newest.durationMs)} · ${newest.eventCount} browser actions · ${newest.chapters?.length || 0} chapters · ${formatBytes(newest.video.sizeBytes)}`;

    $("title").value = newest.title || "KT Session";
    $("description").value = newest.description || "";
    $("preview").src = newest.video.dataUrl;
    renderChapters(newest);
    show("complete");
  }
})();
