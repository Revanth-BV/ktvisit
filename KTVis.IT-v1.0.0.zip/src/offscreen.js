let mediaStream = null;
let mediaRecorder = null;
let chunks = [];
let startedAt = null;

function pickMimeType() {
  const candidates = [
    "video/webm;codecs=vp9",
    "video/webm;codecs=vp8",
    "video/webm"
  ];
  return candidates.find(type => MediaRecorder.isTypeSupported(type)) || "";
}

async function startDisplayCapture() {
  if (mediaRecorder?.state === "recording") {
    return { ok: false, error: "Capture is already active." };
  }

  try {
    mediaStream = await navigator.mediaDevices.getDisplayMedia({
      video: {
        frameRate: { ideal: 15, max: 15 },
        width: { ideal: 1280, max: 1280 },
        height: { ideal: 720, max: 720 }
      },
      audio: false
    });

    const track = mediaStream.getVideoTracks()[0];
    if (!track) throw new Error("No video track was returned by Chrome.");

    const mimeType = pickMimeType();
    mediaRecorder = new MediaRecorder(
      mediaStream,
      mimeType
        ? { mimeType, videoBitsPerSecond: 1800000 }
        : { videoBitsPerSecond: 1800000 }
    );

    chunks = [];
    startedAt = Date.now();

    mediaRecorder.ondataavailable = event => {
      if (event.data?.size) chunks.push(event.data);
    };

    mediaRecorder.onerror = event => {
      console.error("Replay MediaRecorder error:", event.error);
    };

    track.addEventListener("ended", () => {
      if (mediaRecorder?.state === "recording" || mediaRecorder?.state === "paused") {
        mediaRecorder.stop();
      }
    }, { once: true });

    mediaRecorder.start(1000);

    return { ok: true, mimeType: mediaRecorder.mimeType || mimeType || "video/webm" };
  } catch (error) {
    mediaStream?.getTracks().forEach(track => track.stop());
    mediaStream = null;
    return {
      ok: false,
      error: `${error.name || "CaptureError"}: ${error.message || "Capture was not started."}`
    };
  }
}

function getCaptureState() {
  return {
    ok: true,
    active: Boolean(mediaRecorder),
    state: mediaRecorder?.state || "inactive"
  };
}

function pauseCapture() {
  if (!mediaRecorder) {
    return { ok: false, state: "inactive", error: "Video recorder does not exist." };
  }

  if (mediaRecorder.state === "paused") {
    return { ok: true, state: "paused" };
  }

  if (mediaRecorder.state !== "recording") {
    return { ok: false, state: mediaRecorder.state, error: `Video recorder is ${mediaRecorder.state}.` };
  }

  try {
    mediaRecorder.pause();

    return {
      ok: mediaRecorder.state === "paused",
      state: mediaRecorder.state,
      error: mediaRecorder.state === "paused"
        ? null
        : `Recorder remained ${mediaRecorder.state} after Pause.`
    };
  } catch (error) {
    return {
      ok: false,
      state: mediaRecorder.state,
      error: `${error.name || "PauseError"}: ${error.message || "Unable to pause video recorder."}`
    };
  }
}

function resumeCapture() {
  if (!mediaRecorder) {
    return { ok: false, state: "inactive", error: "Video recorder does not exist." };
  }

  if (mediaRecorder.state === "recording") {
    return { ok: true, state: "recording" };
  }

  if (mediaRecorder.state !== "paused") {
    return { ok: false, state: mediaRecorder.state, error: `Video recorder is ${mediaRecorder.state}.` };
  }

  try {
    mediaRecorder.resume();

    return {
      ok: mediaRecorder.state === "recording",
      state: mediaRecorder.state,
      error: mediaRecorder.state === "recording"
        ? null
        : `Recorder remained ${mediaRecorder.state} after Resume.`
    };
  } catch (error) {
    return {
      ok: false,
      state: mediaRecorder.state,
      error: `${error.name || "ResumeError"}: ${error.message || "Unable to resume video recorder."}`
    };
  }
}

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

async function stopCapture() {
  if (!mediaRecorder) return { ok: false, error: "No active video capture." };

  const recorder = mediaRecorder;

  return new Promise(resolve => {
    recorder.onstop = async () => {
      try {
        const blob = new Blob(chunks, { type: recorder.mimeType || "video/webm" });
        const dataUrl = await blobToDataUrl(blob);

        mediaStream?.getTracks().forEach(track => track.stop());

        const result = {
          ok: true,
          video: {
            mimeType: blob.type,
            sizeBytes: blob.size,
            durationMs: Date.now() - startedAt,
            dataUrl
          }
        };

        mediaStream = null;
        mediaRecorder = null;
        chunks = [];
        startedAt = null;

        resolve(result);
      } catch (error) {
        resolve({ ok: false, error: `${error.name || "VideoError"}: ${error.message || "Could not finalize video."}` });
      }
    };

    if (recorder.state === "inactive") {
      recorder.onstop();
    } else {
      recorder.stop();
    }
  });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "START_DISPLAY_CAPTURE") {
    startDisplayCapture().then(sendResponse);
    return true;
  }
  if (message?.type === "PAUSE_CAPTURE") {
    sendResponse(pauseCapture());
    return true;
  }
  if (message?.type === "RESUME_CAPTURE") {
    sendResponse(resumeCapture());
    return true;
  }
  if (message?.type === "GET_CAPTURE_STATE") {
    sendResponse(getCaptureState());
    return true;
  }
  if (message?.type === "STOP_CAPTURE") {
    stopCapture().then(sendResponse);
    return true;
  }
});
