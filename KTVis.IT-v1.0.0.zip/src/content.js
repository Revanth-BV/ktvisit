(() => {
  let recording = false;
  let paused = false;
  let overlay = null;
  let stateVersion = -1;
  let chapterBusy = false;
  let transitionInProgress = false;
  const instanceId = `${Date.now()}-${Math.random().toString(36).slice(2)}`;

  const $ = (root, selector) => root?.querySelector(selector);

  function ownsOverlay() {
    return Boolean(
      overlay &&
      overlay.isConnected &&
      overlay.dataset.ktvisitOwner === instanceId
    );
  }

  function send(type, payload = {}) {
    return chrome.runtime.sendMessage({
      type,
      ...payload
    }).catch(() => null);
  }

  function sendCaptureCommand(type) {
    return chrome.runtime.sendMessage({ type }).catch(() => null);
  }

  async function syncCaptureState(pausedNow) {
    return chrome.runtime.sendMessage({
      type: "CAPTURE_STATE_CHANGED",
      paused: Boolean(pausedNow)
    }).catch(() => null);
  }


  let overlayShadow = null;

  function blockKTVisITPointerEvent(event) {
    event.preventDefault();
    event.stopPropagation();
    if (typeof event.stopImmediatePropagation === "function") {
      event.stopImmediatePropagation();
    }
  }

  function createOverlay() {
    if (!document.documentElement) return;

    // There must be exactly one KTVis.IT overlay per page. This matters
    // after an extension reload/update, where an older content-script
    // instance can remain alive until the page itself is reloaded.
    document
      .querySelectorAll("#replay-kt-overlay-host")
      .forEach(existing => existing.remove());

    overlay = document.createElement("div");
    overlay.id = "replay-kt-overlay-host";
    overlay.dataset.ktvisitOwner = instanceId;
    overlay.setAttribute("data-replay-ui", "true");
    overlay.style.cssText = [
      "position:fixed",
      "top:14px",
      "right:14px",
      "z-index:2147483647",
      "width:fit-content",
      "height:fit-content",
      "pointer-events:auto"
    ].join(";");

    overlayShadow = overlay.attachShadow({ mode: "closed" });

    const style = document.createElement("style");
    style.textContent = `
      :host { all: initial; }
      .bar {
        display:flex; align-items:center; gap:7px;
        padding:8px 10px;
        border:1px solid rgba(255,255,255,.14);
        border-radius:12px;
        background:rgba(10,14,19,.94);
        color:#fff;
        box-shadow:0 8px 30px rgba(0,0,0,.35);
        font:600 12px/1 system-ui,sans-serif;
        backdrop-filter:blur(10px);
        user-select:none;
        pointer-events:auto;
        white-space:nowrap;
      }
      .state-dot {
        width:9px;height:9px;border-radius:50%;
        display:inline-block;
        background:#ff4d4d;
        box-shadow:0 0 10px rgba(255,77,77,.8);
        flex:0 0 auto;
      }
      .state-dot.paused {
        background:#ffc857;
        box-shadow:0 0 10px rgba(255,200,87,.8);
      }
      button {
        border:1px solid rgba(255,255,255,.12);
        background:#1b2530;color:#f5f7fa;
        border-radius:8px;padding:7px 9px;
        cursor:pointer;font:700 11px system-ui,sans-serif;
        pointer-events:auto;
      }
      button:hover { background:#273341; }
      button:active { transform:translateY(1px); }
      button.stop { background:#c9363e;border-color:#c9363e; }
      button:disabled { opacity:.65;cursor:wait; }
      .chapter-input {
        width:150px;padding:7px 8px;border-radius:8px;
        border:1px solid #3b4652;background:#0f151b;color:white;
        outline:none;font:500 11px system-ui,sans-serif;
      }
    `;

    const bar = document.createElement("div");
    bar.className = "bar";
    bar.innerHTML = `
      <span class="state-dot" aria-label="Recording state"></span>
      <button class="chapter" type="button">📌 Chapter</button>
      <button class="pause" type="button">Ⅱ Pause</button>
      <button class="stop" type="button">■ Stop</button>
    `;

    overlayShadow.append(style, bar);
    document.documentElement.appendChild(overlay);

    const stopEvent = event => {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation?.();
    };

    const chapterButton = bar.querySelector(".chapter");
    const pauseButton = bar.querySelector(".pause");
    const stopButton = bar.querySelector(".stop");

    // Capture-phase handlers prevent the host page from swallowing clicks.
    chapterButton.addEventListener("click", event => {
      stopEvent(event);
      beginChapterInput(chapterButton);
    }, true);

    pauseButton.addEventListener("click", async event => {
      stopEvent(event);
      if (!recording || transitionInProgress) return;

      const wasPaused = paused;

      transitionInProgress = true;
      pauseButton.disabled = true;

      try {
        const result = await send(wasPaused ? "RESUME_RECORDING" : "PAUSE_RECORDING");

        if (!result?.ok) {
          console.warn("KTVis.IT pause/resume failed:", result?.error);
          alert(
            `KTVis.IT could not ${wasPaused ? "resume" : "pause"} the recording.\n\n` +
            `${result?.error || "Chrome did not complete the requested transition."}`
          );
          return;
        }

        // The response belongs to this exact button click. It is the only
        // source allowed to transition this overlay after initialization.
        recording = true;
        paused = Boolean(result.paused);

        if (Number.isFinite(Number(result.stateVersion))) {
          stateVersion = Number(result.stateVersion);
        }

        updateOverlay();
      } catch (error) {
        paused = wasPaused;
        updateOverlay();

        console.error("KTVis.IT pause/resume exception:", error);
        alert(
          `KTVis.IT could not ${wasPaused ? "resume" : "pause"} the recording.\n\n` +
          `${error?.message || error}`
        );
      } finally {
        transitionInProgress = false;
        pauseButton.disabled = false;
        updateOverlay();
      }
    }, true);

    stopButton.addEventListener("click", async event => {
      stopEvent(event);
      if (!recording) return;

      stopButton.disabled = true;
      stopButton.textContent = "Creating…";

      try {
        const result = await send("STOP_RECORDING");

        if (!result?.ok) {
          console.error("KTVis.IT stop failed:", result?.error);
          stopButton.disabled = false;
          stopButton.textContent = "■ Stop";
          alert(`KTVis.IT could not stop the recording.\n\n${result?.error || "Unknown error"}`);
          return;
        }

        // The popup may be closed. It will still show the completed session
        // the next time it is opened because the session is persisted by the SW.
        removeOverlay();
      } catch (error) {
        console.error("KTVis.IT stop exception:", error);
        stopButton.disabled = false;
        stopButton.textContent = "■ Stop";
        alert(`KTVis.IT could not stop the recording.\n\n${error.message}`);
      }
    }, true);

    // Prevent mousedown/up from reaching the host page as well.
    for (const button of [chapterButton, pauseButton, stopButton]) {
      button.addEventListener("mousedown", blockKTVisITPointerEvent, true);
      button.addEventListener("mouseup", blockKTVisITPointerEvent, true);
      button.addEventListener("pointerdown", blockKTVisITPointerEvent, true);
      button.addEventListener("pointerup", blockKTVisITPointerEvent, true);
    }
  }

  function beginChapterInput(button) {
    if (!recording || paused || chapterBusy) return;
    chapterBusy = true;

    const input = document.createElement("input");
    input.className = "chapter-input";
    input.placeholder = "Chapter name";
    input.maxLength = 120;

    button.replaceWith(input);
    input.focus();

    let done = false;

    const finish = async save => {
      if (done) return;
      done = true;

      const name = input.value.trim();
      if (save && name) {
        const result = await send("ADD_CHAPTER", { name });
        if (!result?.ok) console.warn("KTVis.IT chapter failed:", result?.error);
      }

      chapterBusy = false;

      if (!input.isConnected || !overlayShadow) return;

      const newButton = document.createElement("button");
      newButton.className = "chapter";
      newButton.type = "button";
      newButton.textContent = "📌 Chapter";

      newButton.addEventListener("click", event => {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation?.();
        beginChapterInput(newButton);
      }, true);

      newButton.addEventListener("mousedown", blockKTVisITPointerEvent, true);
      newButton.addEventListener("mouseup", blockKTVisITPointerEvent, true);
      newButton.addEventListener("pointerdown", blockKTVisITPointerEvent, true);
      newButton.addEventListener("pointerup", blockKTVisITPointerEvent, true);

      input.replaceWith(newButton);
    };

    input.addEventListener("keydown", event => {
      event.stopPropagation();
      if (event.key === "Enter") finish(true);
      if (event.key === "Escape") finish(false);
    }, true);

    input.addEventListener("blur", () => finish(true));
  }

  function updateOverlay() {
    if (!ownsOverlay()) return;

    const stateDot = overlayShadow?.querySelector(".state-dot");
    const pauseButton = overlayShadow?.querySelector(".pause");

    if (!stateDot || !pauseButton) return;

    stateDot.classList.toggle("paused", paused);
    pauseButton.textContent = paused ? "▶ Resume" : "Ⅱ Pause";
    pauseButton.disabled = false;
  }

  function removeOverlay() {
    recording = false;
    paused = false;
    overlay?.remove();
    overlay = null;
    overlayShadow = null;
  }

  function setRecordingState(isRecording, isPaused, authoritativeElapsedMs = null, incomingVersion = null) {
    if (
      incomingVersion !== null &&
      Number.isFinite(incomingVersion) &&
      stateVersion >= 0 &&
      incomingVersion < stateVersion
    ) {
      return;
    }

    if (incomingVersion !== null && Number.isFinite(incomingVersion)) {
      stateVersion = incomingVersion;
    }

    recording = isRecording;
    paused = isPaused;

    if (!recording) {
      removeOverlay();
      return;
    }

    if (!overlay || !overlay.isConnected) {
      createOverlay();
    }

    updateOverlay();
  }

  chrome.runtime.onMessage.addListener(message => {
    if (message?.type !== "RECORDING_STATE") return;

    // Stop must always tear down this tab's overlay.
    if (!message.recording) {
      setRecordingState(false, false, 0, message.stateVersion);
      return;
    }

    // Once this tab has its own active overlay, its Pause/Resume button
    // response owns the UI state. Background broadcasts are for initializing
    // other tabs, not for repainting this active overlay.
    if (recording) return;

    setRecordingState(
      true,
      Boolean(message.paused),
      typeof message.elapsedMs === "number" ? message.elapsedMs : null,
      typeof message.stateVersion === "number" ? message.stateVersion : null
    );
  });

  chrome.runtime.sendMessage({ type: "GET_STATUS" }).then(status => {
    if (status?.ok && status.recording) {
      stateVersion = Number.isFinite(status.stateVersion) ? status.stateVersion : -1;
      recording = true;
      paused = Boolean(status.paused);
      displayElapsedMs = Math.max(0, Number(status.elapsedMs || 0));
      displaySyncedAt = Date.now();
      createOverlay();
      startTimer();
      updateOverlay();
    }
  }).catch(() => {});
})();
