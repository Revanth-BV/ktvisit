# KTVis.IT v0.3.1 — KT Experience Fix

KTVis.IT is a privacy-first Chrome knowledge-transfer recorder.

## v0.3

- User-approved Screen / Window / Chrome Tab capture
- No audio
- Compressed WebM
- Floating in-browser recording controls
- Pause / Resume
- Manual chapters during recording
- Chapter timestamps aligned to video time
- Clickable chapter list that seeks the video
- Browser action timeline
- Local session metadata
- Video preview and download
- No backend or external API

## Test

1. Remove the older KTVis.IT extension from `chrome://extensions`.
2. Extract this package.
3. Load the folder with **Load unpacked**.
4. Open a normal webpage.
5. Click **Start KT Recording**.
6. Choose a tab/window/screen.
7. Perform the KT task.
8. Use the floating **📌 Chapter** button at important points.
9. Test **Pause / Resume**.
10. Stop the recording.
11. Click chapter entries in the finished session to jump the video.

## Important

The video is currently a normal WebM file. It is not yet an enterprise-protected artifact. Do not treat the downloadable file as confidential DRM-protected content.

The next security phase will address protected KT packages, watermarking, access control and organization policy integration.

## Roadmap

v0.4 — Protected KT knowledge package
v1.0 — KTVis.IT workflow execution
v2.0 — Shadow repeated-workflow detection


## v0.3.1 reliability fix

The floating recording controls now live inside a closed Shadow DOM and use capture-phase event handlers so page-level JavaScript cannot swallow KTVis.IT's Chapter, Pause/Resume, or Stop clicks.

Stopping from the floating control also persists the finished session so it is recovered when the KTVis.IT popup is opened again.


## v0.3.2 — Recording Indicator

KTVis.IT now shows a red dot badge on the KTVis.IT extension icon while a KT recording is actively running.

- 🔴 Red dot while recording
- Indicator clears while paused
- Indicator returns on resume
- Indicator clears when stopped
- Indicator clears if recording startup fails


## v0.3.3 — Focused KT UX

The low-value **View Captured Steps** UI has been removed.

KTVis.IT no longer presents raw browser events such as clicks, scrolls, and inputs as a user-facing KT artifact. The structured event data remains available internally so it can later support meaningful capabilities such as intelligent chapters or KTVis.IT automation, without cluttering the KT experience.


## v0.3.4 — Runtime error fixes

Fixed:
- `ReferenceError: stopEvent is not defined` in floating chapter controls.
- Defensive popup badge DOM handling for recording-state messages.
- Popup lifecycle race conditions that could result in `classList` access on a missing element.

The raw captured-step UI remains removed.


## v0.3.5 — Popup lifecycle fix

Fixed the remaining `Cannot read properties of null (reading 'classList')` error.

The popup's `show()` function no longer references the removed captured-steps screen. Timer updates are also guarded when the popup DOM is unavailable.


## v0.3.6 — KTVis.IT Brand

The extension has been renamed from Replay to **KTVis.IT**.

**Positioning:** Make Knowledge Transfer Visible.

The current release keeps the stable recording engine unchanged while updating the product identity and user-facing branding.


## v0.3.8 — Official KTVis.IT Icon

The approved KTVis.IT visual identity is now included at 16, 32, 48, and 128 px sizes and configured for both the extension manifest and toolbar action.

The recording engine is unchanged from the stable release.


## v0.3.8 — Branding and Recording Overlay Fix

Fixed the final release-candidate issues:
- Corrected the popup brand casing to **KTVis.IT**.
- Changed the Chrome toolbar hover title from **Replay** to **KTVis.IT**.
- Fixed the content-script syntax error caused by an invalid function identifier introduced during the branding rename.
- Restored the floating Chapter, Pause, and Stop controls by fixing the content script parse failure.


## v0.4.0 — Pause/Resume Timer Fix

Fixed a race condition between the floating Pause/Resume button and the background recording-state broadcast.

Previously, both paths could account for the same pause interval, causing the elapsed timer to effectively freeze after Resume. Pause timing is now idempotent regardless of which state update arrives first.

Also made the `KTVis.IT` popup casing explicit so the brand is rendered exactly as `KTVis.IT`.


## v0.4.0 — Pause/Resume Stability

Pause/resume timing is now synchronized to the background recording clock. The floating overlay no longer performs independent pause-duration accounting, and the service worker returns authoritative elapsed time with each pause/resume state transition. Chapter creation therefore uses the same authoritative state and cannot race the Resume operation.


## v0.4.1 — Authoritative Clock Sync

The recording overlay now uses the service worker's authoritative elapsed time as a synchronization point. While recording, the timer advances from that point; while paused, it remains fixed.

Recording-state broadcasts now include a monotonically increasing stateVersion. Older state messages are ignored, preventing an out-of-order PAUSED message from arriving after RESUME and freezing the display.

MediaRecorder pause/resume behavior is unchanged.


## v0.4.2 — Authoritative Timer

The recording overlay and popup no longer advance their own local elapsed-time clock.

Every 500 ms they query `GET_STATUS` from the background recording engine and render its authoritative `elapsedMs` value. Pause therefore freezes the displayed value only while the recording engine is paused; Resume causes the next authoritative status response to advance immediately.

State-version ordering is retained so stale PAUSED messages cannot overwrite a newer RESUMED state.


## v0.4.3 — Resume Reliability

Pause/Resume now verifies the actual MediaRecorder state inside the offscreen capture document before the background recording state changes.

Resume includes a controlled retry for deferred Chrome state transitions. If Chrome refuses to resume, KTVis.IT now surfaces the exact failure instead of silently leaving the overlay in PAUSED state.

The background state remains authoritative only after the MediaRecorder transition is confirmed.


## v0.4.4 — Direct MediaRecorder Control

Removed asynchronous polling from the offscreen Pause/Resume command path. The MediaRecorder state is checked immediately after the synchronous `pause()` / `resume()` call, preventing the runtime message channel from remaining open while waiting for a state transition.

Background-to-offscreen messages now have a 3-second timeout so the floating controls cannot remain indefinitely in `Pausing…` or `Resuming…`.

The recording badge remains visible while paused because a recording session is still active.


## v0.4.5 — Capture Flow Fix

Fixed a regression introduced in v0.4.4: the global offscreen message timeout could fire while Chrome was waiting for the user to choose a tab, window, or screen in the display-capture picker.

`START_DISPLAY_CAPTURE` and final video capture now use the normal message bridge again, while Pause/Resume controls retain a targeted timeout so they cannot hang indefinitely.

The direct MediaRecorder Pause/Resume control from v0.4.4 is preserved.


## v0.4.6 — Pause Message Bridge Fix

Fixed a regression where the synchronous MediaRecorder `pauseCapture()` and `resumeCapture()` functions were still being treated as Promises by the offscreen runtime message listener.

The listener now calls `sendResponse()` directly with the synchronous transition result. Background state is committed only when the offscreen recorder confirms the requested MediaRecorder state.


## v0.4.7 — MediaRecorder Event Fix

Pause/Resume now waits for the MediaRecorder's actual `pause` and `resume` events instead of inspecting `mediaRecorder.state` immediately after calling `pause()` / `resume()`.

This is important because MediaRecorder state transitions are asynchronous: an immediate state read can still report `paused` immediately after `resume()` even though Chrome is processing the transition.

A finite 2.5-second control timeout remains in the background bridge.


## v0.4.8 — Pause Restore / Resume Fix

Restored the proven synchronous MediaRecorder pause path from v0.4.6 because the event-wait implementation in v0.4.7 prevented Pause from completing.

Resume remains asynchronous and waits for the MediaRecorder `resume` event, with an immediate-state fallback and a bounded timeout.

The capture-start message bridge remains unbounded so the Chrome share chooser cannot be interrupted by the control timeout.


## v0.5.0 — Direct Capture Control

Pause/Resume control is now sent directly from the KTVis.IT recording overlay to the offscreen MediaRecorder.

The previous path was:
overlay → background service worker → offscreen document.

The new path is:
overlay → offscreen MediaRecorder → background state synchronization.

This removes the message hop that was leaving the overlay stuck on `Pausing…` / `Resuming…`.

The background service worker remains authoritative for elapsed time, chapters, events, and final session state.


## v0.6.0 — Pause Bridge Corrected

Root cause identified: Chrome content scripts send `chrome.runtime.sendMessage()` to the extension service worker, not directly to the offscreen document.

v0.5.0 incorrectly attempted to send `PAUSE_CAPTURE` and `RESUME_CAPTURE` from the content script. The offscreen MediaRecorder therefore never received the commands, which is why the UI could show Pausing/Resuming while the video continued recording.

The correct control path is restored:

content script → background service worker → offscreen document → MediaRecorder

No segmented recording is required. The existing MediaRecorder pause/resume implementation is retained.


## v0.6.1 — Targeted Offscreen Bridge

The service worker now explicitly targets `ktvisit-offscreen` when sending MediaRecorder commands.

The offscreen document ignores unrelated extension messages and only handles commands carrying that target. This removes ambiguity in `chrome.runtime.sendMessage()` when popup/content/background/offscreen contexts are all active.

Pause and Resume still use the existing MediaRecorder implementation; only message routing was changed.


## v0.6.2 — Targeted Start Capture Fix

v0.6.1 correctly added an explicit target to control messages, but the offscreen
listener was then made to reject all un-targeted messages. The normal
`START_DISPLAY_CAPTURE` path was still using the old un-targeted bridge, so the
capture request was silently ignored and the popup reported "Unable to start
display capture."

v0.6.2 applies the `ktvisit-offscreen` target to the normal offscreen bridge as
well. This restores Start Recording while retaining targeted Pause/Resume
routing.


## v0.6.3 — Known-Good Pause Path

Reverted Pause/Resume routing and MediaRecorder control to the exact minimal
pattern used by the known-good Replay v0.3.5 recording engine.

Removed:
- offscreen target filtering
- targeted runtime messages
- MediaRecorder state polling
- MediaRecorder event waiting
- immediate state validation after pause/resume

The path is again:
content → service worker → offscreen → MediaRecorder.pause()/resume()

This isolates the Pause regression from all experimental control changes.


## v0.6.4 — Recorder State Verified

Fixed the concrete Resume failure in v0.6.3: `resumeCapture()` was synchronous
but the offscreen message listener still called `.then(sendResponse)`.

Pause and Resume now both return the actual `MediaRecorder.state`, and the
background service worker only changes KTVis.IT's authoritative state when the
recorder reports the requested state.

Also added the previously referenced `getCaptureState()` implementation.


## v0.6.5 — Overlay State Sync

Fixed the floating KTVis.IT control getting stuck on `Pausing…` / `Resuming…`
while the actual recorder and popup had already transitioned.

The overlay now:
- always redraws after a Pause/Resume request completes;
- immediately re-reads authoritative service-worker state after a successful transition;
- accepts the service worker's latest RECORDING_STATE without rejecting it due
  to a local state-version race.

The recording engine itself is unchanged in this release.


## v0.6.6 — State Version Race Fix

Root cause of the remaining floating-overlay issue: Pause and Resume broadcasts
are delivered asynchronously to tabs. A PAUSED message from the earlier
transition could arrive after the newer RECORDING message and overwrite the
overlay, leaving it visually stuck on Paused/Resuming even though the actual
recorder and popup had resumed.

`setRecordingState()` now rejects any incoming `RECORDING_STATE` message whose
stateVersion is older than the newest state already known by that tab.

This release changes only overlay state ordering; MediaRecorder control and
background elapsed-time logic are untouched.


## v0.6.7 — Overlay Transition Lock

The recording engine is already functionally correct. This release isolates
the floating UI from asynchronous state races during Pause/Resume.

While a Pause/Resume command is in flight, status polling and RECORDING_STATE
broadcasts are ignored. The command response directly updates the overlay,
then a delayed authoritative status refresh runs 250ms later.

This prevents a stale asynchronous status response from changing the overlay
back to PAUSED or leaving it on Pausing/Resuming.


## v0.6.8 — Single Overlay State Machine

This release treats the floating control as its own UI state machine rather
than allowing three asynchronous sources to compete over the DOM.

Changes:
- Exactly one KTVis.IT overlay is allowed per page.
- Each content-script instance gets an ownership token.
- An older overlay instance cannot repaint the current overlay.
- Pause/Resume no longer shows `Pausing…` or `Resuming…`.
- The UI optimistically switches immediately to the requested state.
- The command response confirms the actual recorder state.
- Failed commands roll the UI back.
- GET_STATUS requests started before a transition can no longer overwrite
  the post-transition UI.
- Authoritative re-sync is delayed until 1.6 seconds after the transition.

The MediaRecorder implementation and background recording logic are unchanged.


## v0.6.9 — Local Overlay State

The floating overlay no longer participates in continuous background state
synchronization.

After a tab initializes from GET_STATUS/RECORDING_STATE, its overlay state is
owned locally:
- Pause/Resume command responses update the overlay.
- The overlay uses a local elapsed-time clock between transitions.
- Background RECORDING_STATE broadcasts cannot overwrite an active overlay.
- Continuous GET_STATUS polling was removed.
- Stop broadcasts still tear down the overlay.

The background service worker and MediaRecorder remain authoritative for the
actual recording/session. This isolates the floating UI from asynchronous
cross-tab state races.

Also removed from the popup:
- `0 browser actions captured`
- `Use the floating KTVis.IT controls in the browser to pause, add chapters, or stop.`


## v0.6.10 — Popup State Sync

Video review showed the exact remaining mismatch: the floating overlay correctly
showed `Resume` (meaning PAUSED) while the open KTVis.IT popup still showed
`RECORDING`.

The popup previously received RECORDING_STATE but only updated its internal
variables; it did not redraw the visible popup section.

v0.6.10 makes the popup redraw immediately on every authoritative
RECORDING_STATE message, including Pause, Resume, and Stop. The popup timer is
also refreshed from the broadcast.


## v0.7.0 — Minimal Pause/Resume UI

The floating recorder controls have been deliberately simplified:
- Removed the RECORDING text from the floating bar.
- Removed the elapsed timer from the floating bar.
- Kept Chapter and Stop.
- Pause button becomes Resume while paused.
- Left state indicator is red while recording and yellow while paused.
- Extension action badge is red while recording, yellow while paused, and
  completely hidden when inactive.

The recording engine and video generation remain unchanged.
